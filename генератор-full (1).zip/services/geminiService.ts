import { GoogleGenAI } from "@google/genai";
import type { AnimalData, YouTubeContentDualLang, VideoPromptsDualLang } from '../types';

// Initialize the Google Gemini API client.
// The API key is automatically sourced from the environment.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

async function callGemini<T>(prompt: string): Promise<T> {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-pro',
      contents: prompt,
    });
    
    let content = response.text;

    if (!content) {
        throw new Error("Invalid response structure from Gemini API: No content.");
    }
    
    // Clean the response: Some models wrap JSON in markdown code blocks.
    const jsonMatch = content.match(/```json\s*([\s\S]*?)\s*```/);
    if (jsonMatch && jsonMatch[1]) {
        content = jsonMatch[1];
    }
    
    return JSON.parse(content.trim()) as T;

  } catch (error) {
    console.error("Error communicating with Gemini API:", error);
    if (error instanceof SyntaxError) {
      console.error("Failed to parse JSON response from Gemini. The model may have returned an invalid format.", { response: error });
      throw new Error("Failed to parse the AI model's response. It might not be valid JSON.");
    }
    if (error instanceof Error) {
        throw error;
    }
    throw new Error('An unknown error occurred during the API call.');
  }
}

export async function generateUniqueAnimal(existingAnimals: string[]): Promise<AnimalData> {
    const existingAnimalsList = existingAnimals.length > 0 ? existingAnimals.join(', ') : 'Нет';
    
    const prompt = `Сгенерируй информацию об интересном и, по возможности, не самом известном животном в формате JSON.
    Стремись к максимальному разнообразию в каждой новой генерации: предлагай животных разных видов (млекопитающие, птицы, рыбы, насекомые, рептилии, амфибии), из разных регионов мира.

    Не повторяй животных из этого списка: ${existingAnimalsList}.

    JSON должен содержать три ключа:
    1. "animalName": Название животного с указанием вида/породы (например, "Мадагаскарская руконожка Ай-ай").
    2. "russianArticle": Сценарий для вирусного вертикального видео (YouTube Shorts, Reels, TikTok) на русском языке (80-110 слов). Текст должен быть написан так, чтобы его было интересно слушать и он удерживал внимание зрителя до конца (цель - retention > 80%).
        - **Структура сценария:**
            - **Крюк (первые 2-3 секунды):** Начни с шокирующего вопроса или невероятного утверждения, которое мгновенно захватывает внимание. Например: "Это животное умеет летать, хотя у него нет крыльев!" или "Вы не поверите, что ест этот милашка!".
            - **Основная часть:** Раскрой 3-4 самых поразительных и малоизвестных факта. Используй короткие, энергичные предложения. Повествование должно быть динамичным и увлекательным.
            - **Заключение:** Заверши мощной фразой или призывом, который стимулирует комментарии. Например: "Теперь вы знаете больше. Как вам такое создание?".
        - **Стиль:** Разговорный, энергичный, интригующий, будто лучший друг рассказывает что-то невероятное.
    3. "englishArticle": Точный перевод русского сценария на английский язык, сохраняя тот же вирусный, энергичный и увлекательный стиль.
    
    Важно: твой ответ должен быть исключительно в формате JSON-объекта, без каких-либо пояснений или markdown-форматирования.`;

    return callGemini<AnimalData>(prompt);
}

export async function generateYouTubeContent(animalName: string, russianArticle: string, englishArticle: string): Promise<YouTubeContentDualLang> {
    const prompt = `На основе информации о животном "${animalName}" и сценариев (русской и английской версией), сгенерируй контент для YouTube Shorts на ДВУХ языках.

    Русский сценарий: "${russianArticle}"
    Английский сценарий: "${englishArticle}"
    
    **Задача:** Создать **вирусный, максимально кликабельный заголовок** и **супер-вовлекающее описание** для видео, чтобы оно набирало миллионы просмотров.
    
    **Требования к Заголовку (Title):**
    - Создай заголовок, который вызывает непреодолимое любопытство (создает "information gap").
    - Используй сильные, эмоциональные слова.
    - ОБЯЗАТЕЛЬНО добавь релевантный и популярный эмодзи в начале или в конце.
    - Примеры вирусных формул: "ЭТО ЖИВОТНОЕ НЕ ИЗ НАШЕЙ РЕАЛЬНОСТИ 🤯", "Вы НЕ поверите, что умеет делать этот зверь...", "Самое СТРАННОЕ создание на Земле?".
    
    **Требования к Описанию (Description):**
    - Начни с интригующего вопроса, который повторяет или усиливает идею заголовка.
    - В 2-3 предложениях перескажи суть видео, но не раскрывай всех карт, оставь интригу.
    - Закончи открытым вопросом к аудитории, чтобы спровоцировать комментарии (например, "А вы бы испугались, встретив его? 👇" или "Какая способность удивила вас больше всего?").
    - В конце добавь список релевантных тегов для поиска (через запятую, без #).
    
    Результат должен быть в формате JSON с двумя ключами верхнего уровня: "ru" и "en".
    Каждый из этих ключей должен содержать объект с двумя полями:
    1. "title": строка с заголовком на соответствующем языке.
    2. "description": строка с описанием на соответствующем языке.
    
    Важно: твой ответ должен быть исключительно в формате JSON-объекта, без каких-либо пояснений или markdown-форматирования.`;

    return callGemini<YouTubeContentDualLang>(prompt);
}

export async function generateYouTubeTags(animalName: string, article: string): Promise<string> {
    const prompt = `На основе информации о животном "${animalName}" и следующей статьи: "${article}", сгенерируй список релевантных и популярных тегов для YouTube Shorts на английском языке.
    
    **Требования:**
    - Теги должны быть оптимизированы для максимального охвата и обнаружения.
    - Включи основные теги, такие как shorts, ${animalName.replace(/\s+/g, '').toLowerCase()}, animalfacts, cuteanimals, wildlife.
    - Добавь несколько специфичных тегов, основанных на фактах из статьи.
    - Результат должен быть в формате JSON с одним ключом "tags", значение которого - одна строка с тегами, разделенными запятыми, **без использования символа #**.
    
    Важно: твой ответ должен быть исключительно в формате JSON-объекта, без каких-либо пояснений или markdown-форматирования.`;

    const result = await callGemini<{ tags: string }>(prompt);
    return result.tags;
}

export async function generateVideoPrompts(animalName: string, russianArticle: string, englishArticle: string): Promise<VideoPromptsDualLang> {
    const prompt = `На основе статей о '${animalName}' (русской и английской версии), сгенерируй 14 профессиональных и детализированных видео-промтов для модели Veo 3.1 на ДВУХ языках.

    Русская статья: "${russianArticle}"
    Английская статья: "${englishArticle}"
    
    **Требования к промтам:**
    - Для каждого языка должно быть 14 промтов.
    - Каждый промт должен соответствовать фактам, представленным в статье, создавая логичную визуальную последовательность.
    - Промты должны быть написаны в профессиональном формате, включая детали о сцене, освещении, угле съемки и параметрах камеры.
    - Промты для каждого языка должны быть представлены в виде нумерованного списка (1., 2., 3. и т.д.).
    - **ВАЖНО:** Каждый нечетный промт (1, 3, 5...) должен начинаться с таймкода '[0:00-0:04] ', а каждый четный промт (2, 4, 6...) должен начинаться с таймкода '[0:04-0:08] '.

    **Примеры профессионального формата:**
    Пример 1: Hyperrealistic family video: two adult and one baby sugar gliders peeking out from a tree hollow entrance at sunset. The baby cautiously pokes its face out, looks around, then hides back behind an adult. Warm golden light beautifully illuminates their fur. Every gaze and fur texture are rendered with superb detail. Shot on Sony A1, 70-200mm f/2.8 GM II lens set at 150mm, f/3.5, ISO 1000. 8k, exceptional sharpness, touching moment.
    Пример 2: Photorealistic video of a sugar glider expertly balancing on a thin branch that slightly bends under its weight. It slowly moves along the branch, its paws gripping firmly, and its expressive eyes carefully watching the movement. Dynamic angle, focus on its gripping paws and expressive eyes. Natural, diffused jungle light at night. Shot on Canon EOS R3, 135mm f/2L lens, f/2.5, ISO 2000. 8k, professional quality, showcasing agility.

    Отформатируй вывод в виде JSON-объекта с двумя ключами:
    1. 'ru_prompts': значение — одна большая строка (a single string), содержащая 14 пронумерованных промтов на русском. Каждый промт должен быть отделен от следующего настоящим символом новой строки (newline character, \\n).
    2. 'en_prompts': значение — одна большая строка (a single string), содержащая 14 пронумерованных промтов на английском. Каждый промт должен быть отделен от следующего настоящим символом новой строки (newline character, \\n).
    
    Важно: твой ответ должен быть исключительно в формате JSON-объекта, без каких-либо пояснений или markdown-форматирования.`;

    return callGemini<VideoPromptsDualLang>(prompt);
}